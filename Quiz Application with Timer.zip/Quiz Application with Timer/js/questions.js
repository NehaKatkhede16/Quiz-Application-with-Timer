// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Which type of JavaScript language is ___?",
    answer: "Object-Oriented",
    options: [
      "Object-Based",
      "Assembly-language",
      "Object-Oriented",
      "High-level"
    ]
  },
    {
    numb: 2,
    question: "The 'function' and 'var' are known as:",
    answer: "Declaration statements",
    options: [
      "Keywords",
      "Prototypes",
      "Declaration statements",
      "Data types"
    ]
  },
    {
    numb: 3,
    question: "Which of the following is not a loop in Javascript?",
    answer: "forwhile",
    options: [
      "for",
      "while",
      "foreach",
      "forwhile"
    ]
  },
    {
    numb: 4,
    question: "Which of the following is not a javascript framework?",
    answer: "Laravel",
    options: [
      "Vue",
      "React",
      "Node",
      "Laravel"
    ]
  },
    {
    numb: 5,
    question: "Which one is not a comparison operator?",
    answer: "=",
    options: [
      "=",
      "<",
      ">",
      "!="
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....
  {
    numb: 6,
    question: "Which symbol is used separate JavaScript statements?",
    answer: "Semicolon(;)",
    options: [
      "Comma(,)",
      "Colon(:)",
      "Hyphen(_)",
      "Semicolon(;)"
    ]
  },

  {
    numb: 7,
    question: "Which event is related to the keyboard?",
    answer: "onkeydown",
    options: [
      "onfocus",
      "onkeypress",
      "onkeydown",
      "onclick"
    ]
  },

  {
    numb: 8,
    question: " How to write 'Hello world' in alert Box in Javascript?",
    answer: "alert(Hello World)",
    options: [
      "showalert(Hello World)",
      "msg(Hello World)",
      "alert(Hello World)",
      "msgBox(Hello world)"

      
    ]
  },

  {
    numb: 9,
    question: "How to write a comment in Javascript?",
    answer: "//This is a comment",
    options: [
      "/*This is a comment*/",
      "//This is a comment",
      "$$This is a comment$$",
      "**This is a comment**"
    ]
  },

  {
    numb: 10,
    question: "Which method is used to sorts the elements of an array?",
    answer:  "sort()",
    options: [
      "order()",
      "sort()",
      "changeOrder()",
      "None of the above"
    ]
  },

];